angular.module('saasApp').controller('anchorCtrl', ['$anchorScroll', '$location', '$scope',
  function ($anchorScroll, $location, $scope) {
    $scope.gotoAnchor = function(item) {
	  var old = $location.hash();
      $location.hash(item);
	  $anchorScroll();
	  $location.hash(old);
    };
  }
]);