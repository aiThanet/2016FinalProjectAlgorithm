﻿var app = angular.module('saasApp', ['ngRoute','ui.bootstrap','ngSanitize']);


//Configurating routes
app.config(function($routeProvider) {

		$routeProvider
		
		// routing for the whole application
		.when('/', {templateUrl: "home.html", contoller: "homeController"})
		.when('/learning', {templateUrl: "learning.html", contoller: "learnSaaSCtrl"})
		.when('/portfolio', {templateUrl: "portfolio.html", contoller: "portfolioCtrl"})
		.when('/submitrequest', {templateUrl: "submitrequest.html", contoller: "requestCtrl"})
		.when('/networkmeetings', {templateUrl: "networkmeetings.html", contoller: "meetingCtrl"})
		.when('/IaaSPortfolio', {templateUrl: "IaaSPortfolio.html", contoller: "IaaSportfolioCtrl"})
		.when('/IaaS', {templateUrl: "IaaS.html", contoller: "IaaSCtrl"})
		.when('/PaaS', {templateUrl: "PaaS.html", contoller: "IaaSCtrl"})
		.otherwise({redirectTo:'/'});
	
});
/* footer */
function corporateSeparateness() {
                var top = (screen.height/2)-250;
                var left = (screen.width/2)-250; 
    window.open("http://intrattd.na.xom.com/empa/iem/corporate_separateness.htm", "_blank", "toolbar=no, scrollbars=yes, top="+top+", left="+left+" ,resizable=yes, width=1000, height=250");
}

function ownershipGuidelines(){
                var top = (screen.height/2)-400;
                var left = (screen.width/2)-500; 
    window.open("http://ishareteam6.na.xom.com/_layouts/xom/OwnershipGuidelines.htm", "_blank", "toolbar=no, scrollbars=yes,top="+top+", left="+left+", resizable=yes, width=1000, height=400");
}

function privacyGuidelines(){
                var top = (screen.height/2)-800;
                var left = (screen.width/2)-600; 
    window.open("http://ishareteam6.na.xom.com/_layouts/xom/DataPrivacy.htm", "_blank", "toolbar=no scrollbars=yes,top="+top+", left="+left+", resizable=yes, width=1200, height=800");
}


	







	 


	 
