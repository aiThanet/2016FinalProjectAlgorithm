//Controller for the RequestAServiceView.
	 
angular.module('saasApp').controller('requestCtrl', function($scope, $http, $location){	
	$scope.request = {}; //Request object to be sent in the POST
	$scope.cats = getCategories(); // Categories to be shown in the DDL
	$scope.showSuccess = false; // Var to show message
	$scope.showFailure = false;
	$scope.message = "I'm working!"
	$scope.request.RequestedBy = $().SPServices.SPGetCurrentUser(); //Calls SPServices javascript, if commented then works
	$scope.requestTypes = "";
	

	//Retrieve request types from list
	
	//var typeOfRequestsListUrl = "/sites/WDForce/SaaS/_api/web/lists/GetByTitle('TypeOfRequests')/items?$TOP=1000"; // change approach since there is a 100 limit paging from server
	var typeOfRequestsListUrl = "https://ishareteam4.na.xom.com/sites/SaaS/_api/web/lists/GetByTitle('TypeOfRequests')/items?$TOP=1000";
	$scope.init = function(){
	$http({
        headers: {
            'Accept': "application/json; odata=verbose",
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type'
        },
        method: 'GET',
        url: typeOfRequestsListUrl
    }).success(function (data) {
	   console.log(data.d.results);
       $scope.requestTypes = data.d.results;});
    }
    	//$http.get(typeOfRequestsListUrl).success(function(data){
		//console.log(data);
		//$scope.typeOfRequests = data;
	//}) 
	
	//POST request object to SP and shows message
	
function getFormDigest() {
        return $.ajax({
            url: "/sites/Saas/_api/contextinfo",
            method: "POST",
            headers: { "Accept": "application/json; odata=verbose" },
			error: function(err){console.log(err)}
        });
    } 
	$scope.Disable = function(value1)
	{
		return (value1 == "" || value1 == null || value1 == undefined);
	
	}
	$scope.sendRequest = function(){
	
	getFormDigest().then(function(data){
			$scope.request.Category = $scope.categoryValue.s2lv;
			var itemsProperty = { '__metadata': { 'type': 'SP.Data.ServiceRequestListItem' }, 'Category': $scope.categoryValue.s2lv, 'RequestedBy': $scope.request.RequestedBy, 'Description': $scope.request.Description };
			console.log(data);
            $.ajax({

                url: "/sites/SaaS/_api/web/lists/GetByTitle('ServiceRequest')/items",
                method: "POST",
                data: JSON.stringify(itemsProperty),
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
                },
                async: true,		
				success: function (data) {
					//$(".alert alert-success").show();
				   $scope.$apply(function(){ $scope.showFailure=false;	$scope.showSuccess=true; $scope.categoryValue=""; $scope.request.Description="";});					
				},
				error: function (request, status, error) {
					//$(".alert alert-danger").show();
					console.log("Request: "+ request + " status: "+ status + " error: " + error );
					$scope.$apply(function(){ $scope.showFailure=true;	$scope.showSuccess=false; $scope.categoryValue=""; $scope.request.Description="";});	
				}
			});
	}); 
	/* getFormDigest().then(function(data){
			$scope.request.Category = $scope.categoryValue.s2lv;
			var itemsProperty = { '__metadata': { 'type': 'SP.Data.ServiceRequestListItem' }, 'Category': $scope.categoryValue.s2lv, 'RequestedBy': $scope.request.RequestedBy, 'Description': $scope.request.Description };
			console.log(data);
            $.ajax({

                url: "/sites/SaaS/_api/web/lists/GetByTitle('ServiceRequest')/items",
                method: "POST",
                data: JSON.stringify(itemsProperty),
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
                },
                async: false
           })
			.success(function(data){console.log("worked");
				console.log("Request was sent successfully");
				$scope.request = {};
				$scope.showSuccess = true;
				} )
			
			.error(function(data){
				console.log("An error occured!");
				$scope.request = {};
				$scope.showFailure = true;

		})
		 
	}
	); */
	
/*console.log($scope.categoryValue);
		$scope.request.Category = $scope.categoryValue.s2lv;
		$http.post("https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/ServiceRequest",JSON.stringify($scope.request))
		//$http.post("https://ishareteam1.na.xom.com/sites/WDForce/SaaS/_vti_bin/ListData.svc/ServiceRequest",JSON.stringify($scope.request))
		.success(function(item){
			console.log("Request was sent successfully");
			$scope.request = {};
			$scope.showSuccess = true;

			
		})
		.error(function(item){
			console.log("An error occured!");
			$scope.request = {};
			$scope.showFailure = true;

		}) */
	}
	// Cancel request -- go back to main site
	$scope.cancelRequest = function(){
		$location.path('/');
	}
	// Just for testing
	$scope.sendAlert = function(){
	 alert("This function is still under construction!");
	}

	
	//Gets the categories from SP list.
	function getCategories(){
		$http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/ServiceRequestCategory'})
		.success(function(data) {

         $scope.cats = data.d.results;

       });
	}	
})
