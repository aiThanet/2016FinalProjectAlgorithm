angular.module('saasApp').controller('IaaSCtrl', function ($scope, $http){
       $http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		//url:'https://ishareteam1.na.xom.com/sites/WDForce/SaaS/_vti_bin/ListData.svc/IaaSInformationList/'})
		url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/IaaSInfoList?$orderby=Order'})
		.success(function(data) {
		 console.log(data.d.results);
         $scope.IaaSListInfo = data.d.results;
		

       });
	   $scope.message = "Hello there!";
     });