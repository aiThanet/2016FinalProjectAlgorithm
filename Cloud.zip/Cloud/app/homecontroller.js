angular.module('saasApp').controller('homeController', function($scope, $http) {
		
		$http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/ContactUs/'}) 
		.success(function(data) {
			$scope.contactPerson = data.d.results;
			console.log(data.d.results);
		});
		
		$http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		//url:'https://ishareteam1.na.xom.com/sites/WDForce/SaaS/_vti_bin/ListData.svc/ContactUs?$expand=Contact&orderby=Order'}) 
		//url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/ContactUs?$expand=Contact&orderby=t0xp'}) 
		url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/ContactUs?$orderby=Number&$expand=Contact'}) 
		.success(function(data) {
			$scope.contacts = data.d.results;
			console.log(data.d.results);
		});

$scope.convertURL = function(url){
	if(url!= null){
	  var convertedURL = url.substring(0,url.indexOf(","));
	  return convertedURL;
						}	    
					 }; 
});