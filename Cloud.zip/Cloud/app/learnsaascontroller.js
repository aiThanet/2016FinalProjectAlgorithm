angular.module('saasApp').controller('learnSaaSCtrl', function ($scope, $http){
       $http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/LearnSaaS?$orderby=ArtID'}) 
			.success(function(data) {

         $scope.articles = data.d.results;

       });
     })
