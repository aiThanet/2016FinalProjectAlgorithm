angular.module('saasApp').controller('meetingCtrl', function($scope, $http) {
		$http({headers: { 'Accept': "application/json; odata=verbose",
						  'Access-Control-Allow-Origin': '*',
						  'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		//url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/NetworkMeetings/'}) 
		//url:'https://ishareteam4.na.xom.com/sites/SaaS/_vti_bin/ListData.svc/NetworkMeetings?$orderby=MeetingDate%20desc'})
		url:"https://ishareteam4.na.xom.com/sites/SaaS/_api/web/lists/GetByTitle('NetworkMeetings')/items?$TOP=1000"})
		.success(function(data) {

        $scope.data = data.d.results;
		console.log($scope.data);


       });
		

});
