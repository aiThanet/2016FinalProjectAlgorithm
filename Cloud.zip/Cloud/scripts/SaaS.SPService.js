﻿(function () {
    'use strict'

    app.service('SPService', SPService);

    SPService.$inject = ['SettingsService', '$http', '$log'];

    function SPService(SettingsService, $http, $log) {
        var requestDigest = '',
            SPService = this;

        this.RequestDigest = function () {
            return requestDigest;
        };

        this.GetItemTypeForListName = function (name) {
            return ("SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem").replace(/(%20)/g, "_x0020_");
        }

        this.GetSuggestionsFromSearch = function (searchText, successCallback, errorCallback) {
            var userSearchSuggestionEndpoint = SettingsService.siteUrl + '_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface.clientPeoplePickerSearchUser',
                config = {
                    headers: {
                        'Content-Type': 'application/json; odata=verbose',
                        'Accept': 'application/json; odata=verbose',
                        'X-RequestDigest': requestDigest
                    }
                };

            var data = {
                queryParams: {
                    __metadata: {
                        type: 'SP.UI.ApplicationPages.ClientPeoplePickerQueryParameters'
                    },
                    MaximumEntitySuggestions: 50,
                    QueryString: searchText
                }
            };

            return $http.post(userSearchSuggestionEndpoint, data, config)
             .then(successCallback, errorCallback);
        };

        this.GetNewRequestDigest = function (successCallback) {
            if (SettingsService.LoggingEnabled) {
                $log.info('Getting new request digest');
            }

            var requestDigestSucceded = function (data) {
                var getRequestDigestFromData = function (data) {
                    return data.data.d.GetContextWebInformation.FormDigestValue;
                }

                requestDigest = getRequestDigestFromData(data);

                if (SettingsService.LoggingEnabled) {
                    $log.info('X-RequestDigest value:', requestDigest);
                }

                if (successCallback != undefined) {
                    successCallback(data);
                }
            }

            var requestDigestConfig = {
                url: SettingsService.siteUrl + '/_api/contextinfo',
                headers: {
                    'Content-Type': 'application/json; odata=verbose',
                    'Accept': 'application/json; odata=verbose',
                },
                method: 'POST'
            };

            $http(requestDigestConfig).then(requestDigestSucceded);
        };

        this.GetUserInfo = function () {
            var config = {
                headers: {
                    'Accept': 'application/json; odata=verbose'
                }
            };

            var httpGETUrl = SettingsService.siteUrl + "_api/web/CurrentUser";

            $http.get(httpGETUrl, config).then(function (data) {
                SettingsService.currentUser = data.data.d;
				
				$http.get(SettingsService.currentUser.Groups.__deferred.uri, config).then(function(data) {
					SettingsService.currentUser.Groups = undefined;
					SettingsService.currentUser.Groups = data.data.d.results;
					
					if (SettingsService.LoggingEnabled) {
						$log.info('Current User info retrieved.', SettingsService.currentUser);
					}
				});
            });
        };

		this.IsMemberOfOrAdmin = function(groupName) {
			if (SettingsService.currentUser != undefined) {
				return (this.IsMemberOf(groupName) || SettingsService.currentUser.IsSiteAdmin);
			}
		};
		
		this.IsMemberOf = function(groupName) {
			var index = -1;
			
			if (SettingsService.currentUser != undefined) {
				if (SettingsService.currentUser.Groups != undefined) {
					for (var i = 0; i < SettingsService.currentUser.Groups.length; i++) {
						if (SettingsService.currentUser.Groups[i].Title == groupName) {
							index = i;
							
							break;
						}
					}
					
					if (index != -1) {
						return true;
					} else {
						return false;
					}
				}
			}
		};

        this.AddNewSPListItem = function (prop) {
            var listName = prop.listName,
                itemData = prop.itemData,
                operationOnSuccess = prop.success,
                operationOnError = prop.error,
                itemType = SPService.GetItemTypeForListName(listName);
				itemData.__metadata = { type: itemType };

            if (SettingsService.LoggingEnabled) {
                $log.info('Adding new SP item', {
                    itemType: itemType,
                    itemData: itemData
                });
            }

            var url = SettingsService.siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items",
                config = {
                    headers: {
                        'Content-Type': 'application/json; odata=verbose',
                        'Accept': 'application/json; odata=verbose',
                        'X-RequestDigest': SPService.RequestDigest()
                    }
                };

            $http.post(url, JSON.stringify(itemData), config).then(function (data) {
                if (SettingsService.LoggingEnabled) {
                    $log.info('New SP item created', data);
                }

                if (operationOnSuccess != undefined) {
                    operationOnSuccess(data);
                }
            }, function (err) {
                if (SettingsService.LoggingEnabled) {
                    $log.error('Error in HTTP post', err);
                }

                if (operationOnError != undefined) {
                    operationOnError(err);
                }
            });
        };

        this.UpdateSPListItem = function (prop) {
            var listName = prop.listName,
                itemData = prop.itemData,
                id = prop.id,
                operationOnSuccess = prop.success,
                operationOnError = prop.error,
                itemType = SPService.GetItemTypeForListName(listName);

            itemData.__metadata = { type: itemType };

            if (SettingsService.LoggingEnabled) {
                $log.info('Updating SP item', {
                    itemType: itemType,
                    itemData: itemData
                });
            }

            var url = SettingsService.siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items" + (id != undefined ? '(' + id + ')' : ''),
                config = {
                    headers: {
                        'Content-Type': 'application/json; odata=verbose',
                        'Accept': 'application/json; odata=verbose',
                        'X-HTTP-Method': 'MERGE',
                        'If-Match': '*',
                        'X-RequestDigest': SPService.RequestDigest()
                    }
                };

            $http.post(url, JSON.stringify(itemData), config).then(function (data) {
                if (SettingsService.LoggingEnabled) {
                    $log.info('SP item updated', data);
                }

                if (operationOnSuccess != undefined) {
                    operationOnSuccess(data);
                }
            }, function (err) {
                if (SettingsService.LoggingEnabled) {
                    $log.error('Error in HTTP post', err);
                }

                if (operationOnError != undefined) {
                    operationOnError(err);
                }
            });
        }

        this.GetListItems = function (prop) {
            var listName = prop.listName,
                operationOnSuccess = prop.success,
                operationOnError = prop.error,
                filterText = prop.filterText,
                filterLookup = prop.filterLookup,
                filterOperation = prop.filterOperation,
                itemId = prop.itemId,
                expand = prop.expand,
                expandUser = prop.expandUser,
                files = prop.files,
                orderBy = prop.orderBy;

            var urlExtendWithId = '';

            if (itemId != undefined) {
                urlExtendWithId += '(' + itemId + ')';
            };

            var httpGETUrl = SettingsService.siteUrl + '/_api/web/lists/' +
                             listName + 'List/items' + urlExtendWithId;

            if (filterText != undefined) {
                if (filterOperation == 'like') {
                    httpGETUrl += '?$filter=substringof(\'' + filterText + '\', Title)';
                } else if (filterOperation == 'equals') {
                    httpGETUrl += '?$filter=Title eq \'' + filterText + '\'';
                }
            }

            if (filterLookup != undefined) {
                if (filterLookup.fieldName != undefined && filterLookup.fieldValue != undefined) {
                    httpGETUrl += '?$filter=' + filterLookup.fieldName + ' eq ' + filterLookup.fieldValue;
                }
            }

            if (expand != undefined) {
                httpGETUrl += '?$select=*,';

                for (var i = 0; i < expand.length; i++) {
                    var expandField = expand[i];

                    httpGETUrl += expandField + '/Title';

                    if (i != expand.length - 1) {
                        httpGETUrl += ',';
                    }
                }

                httpGETUrl += '&$expand=';

                for (var i = 0; i < expand.length; i++) {
                    var expandField = expand[i];

                    httpGETUrl += expandField;

                    if (i != expand.length - 1) {
                        httpGETUrl += ',';
                    }
                }
            }

            if (expandUser != undefined) {
                httpGETUrl += '?$select=*,';

                for (var i = 0; i < expandUser.length; i++) {
                    var expandField = expandUser[i];

                    httpGETUrl += expandField + '/Title,' + expandField + '/EMail';

                    if (i != expandUser.length - 1) {
                        httpGETUrl += ',';
                    }
                }

                httpGETUrl += '&$expand=';

                for (var i = 0; i < expandUser.length; i++) {
                    var expandField = expandUser[i];

                    httpGETUrl += expandField;

                    if (i != expandUser.length - 1) {
                        httpGETUrl += ',';
                    }
                }
            }

            if (orderBy != undefined) {
                httpGETUrl += '&$orderby=' + orderBy + ' asc';
            }

            if (files == true) {
                httpGETUrl += '/AttachmentFiles';
            }

            var config = {
                headers: { 'Accept': 'application/json; odata=verbose' }
            };

            return $http.get(httpGETUrl, config).then(function (data) {
                if (SettingsService.LoggingEnabled) {
                    $log.info('Get SP list items', data);
                }
                if (operationOnSuccess != undefined) {
                    return operationOnSuccess(data);
                }
            }, function (err) {
                if (SettingsService.LoggingEnabled) {
                    $log.error('Error in getting SP list items', err);
                }

                if (operationOnError != undefined) {
                    operationOnError(err);
                }
            });
        };

        this.GetSPGroup = function (prop, operationOnSuccess, operationOnError) {
            var groupName = prop.GroupName;

            var config = {
                headers: {
                    'Accept': 'application/json; odata=verbose'
                }
            };

            var httpGETUrl = SettingsService.siteUrl + "_api/web/sitegroups/getbyname('" + groupName + "')/Users";

            $http.get(httpGETUrl, config).then(function (data) {
                if (SettingsService.LoggingEnabled) {
                    $log.info('Get SP group succeded', data);
                }
                if (operationOnSuccess != undefined) {
                    return operationOnSuccess(data);
                }
            }, function (err) {
                if (SettingsService.LoggingEnabled) {
                    $log.error('Error in getting SP group', err);
                }

                if (operationOnError != undefined) {
                    operationOnError(err);
                }
            });
        };

        this.CreateUser = function (successCallback) {
            var itemData = {
                "Title": 'Created new user'
            };

            SPService.AddNewSPListItem({
                listName: SettingsService.usersListName,
                itemData: itemData,
                success: successCallback
            });
        };

        this.CreateSPGroup = function (prop, operationOnSuccess, operationOnError) {
            var groupName = prop.GroupName;

            var config = {
                'headers': {
                    'content-type': "application/json; odata=verbose",
                    'Accept': 'application/json; odata=verbose',
                    'body': "{ '__metadata':{ 'type': 'SP.Group' }, 'Title':'" + groupName + "' }",
                    'X-RequestDigest': SPService.RequestDigest()
                }
            };

            var httpPOSTUrl = SettingsService.siteUrl + "_api/web/sitegroups";

            $http.post(httpPOSTUrl, config).then(function (data) {
                if (SettingsService.LoggingEnabled) {
                    $log.info('Get SP group succeded', data);
                }
                if (operationOnSuccess != undefined) {
                    return operationOnSuccess(data);
                }
            }, function (err) {
                if (SettingsService.LoggingEnabled) {
                    $log.error('Error in getting SP group', err);
                }

                if (operationOnError != undefined) {
                    operationOnError(err);
                }
            });
        };

        this.AttachFileToListItem = function (prop, operationOnSuccess, operationOnError) {
            var listName = prop.listName,
                file = prop.file,
                prefix = prop.prefix,
                itemData = {};

            if (SettingsService.LoggingEnabled) {
                $log.info('Uploading new file to SP item', {});
            }

            var reader = new window.FileReader();
            reader.onload = function (event) {
                var fileContent = event.target.result,
                    filename = (prefix == undefined ? '' : (prefix + '_')) + file.name;

                var url = SettingsService.siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items(" + prop.Id + ")/AttachmentFiles/add(FileName='" + filename + "')",
                config = {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined,
                        'Accept': 'application/json; odata=verbose',
                        'X-RequestDigest': SPService.RequestDigest()
                    }
                };

                $http.post(url, fileContent, config).then(function (data) {
                    if (SettingsService.LoggingEnabled) {
                        $log.info('New SP item created', data);
                    }

                    if (operationOnSuccess != undefined) {
                        operationOnSuccess(data);
                    }
                }, function (err) {
                    if (SettingsService.LoggingEnabled) {
                        $log.error('Error in HTTP post', err);
                    }

                    if (operationOnError != undefined) {
                        operationOnError(err);
                    }
                });
            };

            reader.readAsArrayBuffer(file);
        };
    };
})();
