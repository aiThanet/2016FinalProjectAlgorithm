﻿(function () {
	"use strict"

    app.service('SettingsService', SettingsService);

    SettingsService.$inject = ['$http', '$log'];

    function SettingsService($http, $log) {
		this.LoggingEnabled = true;
		this.curentUser = undefined;
		this.settings = {
			useBGImage: true
		};
		
		this.siteUrl = (window.location.protocol + '//' + window.location.host + window.location.pathname)
					   .replace('SiteAssets/index.html', '');
	};
})();