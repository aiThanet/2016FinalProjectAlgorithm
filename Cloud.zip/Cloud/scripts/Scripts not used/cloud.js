$(document).ready(function() {
    var script = document.createElement('script');
script.src = "scripts/cloud2.js";
    window.setTimeout(function () {
        document.getElementsByTagName('body')[0].appendChild(script);
    }, 0); // 2 sec
});

// $(window).load(function() {
	// /* loader gif */
		// (function(){
		// var loader = document.getElementById("loader");

		// var show = function(){
		  // loader.style.display = "block";
		  // setTimeout(hide, 5000);  // 6 seconds
		// }

		// var hide = function(){
		  // loader.style.display = "none";
		// }

		// show();
		  // })();
    // $("#content").fadeIn("slow");
	// $("#top").fadeIn("slow");
	// $("footer").fadeIn("slow");
// });




