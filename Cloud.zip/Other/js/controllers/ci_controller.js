//Declare _ for array usage
var underscore = angular.module('underscore', []);
underscore.factory('_', ['$window', function() {
  return $window._;
}]);

var app = angular.module('CIApp', ['underscore']);

app.config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
]);

app.filter('configFilter', function(){
	return function(items, tag){
		if(items == null )return;
		var value = 0;
		if( tag == null || tag == "" || tag == "All")return items;	
		_.each(items,function(item){
			if(item.Title == tag){
				value = item.Value;
			}
		});
		return value;
	};
});

app.controller('configCtrl', function ($scope, $http){
	$http.defaults.withCredentials = true;
	$http.defaults.headers.get = { "Accept": "application/json;odata=verbose", "Access-Control-Allow-Origin" : "*" ,"Access-Control-Allow-Methods": "GET, POST, OPTIONS" };	
	
	var configUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Configuration')/items";
	
	$http.get(configUrl).success(function(data){
		$scope.config = data.d.results;
		console.log($scope.config);
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});	
	
	var currentName = "Visitor!";
	$scope.name = currentName;
	$http.get("https://ishareteam8.na.xom.com/sites/chemtechci/_api/SP.UserProfiles.PeopleManager/GetMyProperties").success(function(data){
		_.each(data.d.UserProfileProperties.results, function (person){
			if(person.Key == "FirstName") {
				currentName = person.Value;
				$scope.name = currentName;
			}
		});
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});
	
});

app.controller('studyCtrl', function ($scope, $http){
	$http.defaults.withCredentials = true;
	$http.defaults.headers.get = { "Accept": "application/json;odata=verbose", "Access-Control-Allow-Origin" : "*" ,"Access-Control-Allow-Methods": "GET, POST, OPTIONS" };	
	
	var productsUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Products')/items?&$orderby=Title";
	
	$http.get(productsUrl).success(function(data){
		$scope.products = data.d.results;
		console.log($scope.products);
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});	
	
	var competitorsUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Competitors')/items?&$orderby=Title";
	
	$http.get(competitorsUrl).success(function(data){
		$scope.competitors = data.d.results;
		console.log($scope.competitors);
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});	
	
	var segmentsUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Segments')/items?&$orderby=Title";
	
	$http.get(segmentsUrl).success(function(data){
		$scope.segments = data.d.results;
		console.log($scope.segments);
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});	
	
	var presentationsUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Management_Presentations')/items?&$orderby=Title";
	
	$http.get(presentationsUrl).success(function(data){
		$scope.presentations = data.d.results;
		console.log($scope.segments);
	}).error(function (data, status, headers, config) {
		$scope.errorMessage = "Couldn't load the content, error # " + status;
	});	
});

app.controller('contactsCtrl', function ($scope, $http){
	$http.defaults.withCredentials = true;
	$http.defaults.headers.get = { "Accept": "application/json;odata=verbose", "Access-Control-Allow-Origin" : "*" ,"Access-Control-Allow-Methods": "GET, POST, OPTIONS" };	
	
	var contactsUrl = "https://ishareteam8.na.xom.com/sites/chemtechci/_api/web/lists/GetByTitle('CI_Contacts')/items?$expand=Person";
	var sortedContacts= [];
	
	$http({headers: { 'Accept': "application/json; odata=verbose", 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type'}, 
		method: 'GET', 
		url:'https://ishareteam8.na.xom.com/sites/chemtechci/_vti_bin/ListData.svc/CI_Contacts/?$expand=Person'}) 
	.success(function(data) {
		var aux = _.each(data.d.results, function(elem){
			sortedContacts.push(elem);
			return elem;
		});
		console.log(_.union(sortedContacts, aux));
		$scope.contacts = _.union(sortedContacts, aux);
    });
	
	$scope.mysitepic = function(employee){
		if(employee.Picture!= null){
			var pic = employee.Picture.split(',',1).toString();
			return pic;
		}
	}; 
	
	$scope.mysiteLink = function(employee){
		var employeeStr = employee.AccountName;
		employeeStr = employeeStr.toLowerCase();
		var split = employeeStr.split("\\");
		var employeeLanId = split[1];
		var employeeDomain = split[0];
		
		return "https://mysite.na.xom.com/personal/"+employeeDomain+"_"+employeeLanId;
	}; 
});
